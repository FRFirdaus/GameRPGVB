﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Show = New System.Windows.Forms.Timer(Me.components)
        Me.btnSHOP = New System.Windows.Forms.Button()
        Me.Hide = New System.Windows.Forms.Timer(Me.components)
        Me.lblMONEY = New System.Windows.Forms.Label()
        Me.lblINFORMASI = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.senjata2 = New System.Windows.Forms.PictureBox()
        Me.frostbite = New System.Windows.Forms.PictureBox()
        Me.armor2 = New System.Windows.Forms.PictureBox()
        Me.senjata3 = New System.Windows.Forms.PictureBox()
        Me.armor3 = New System.Windows.Forms.PictureBox()
        Me.Lightningbolt = New System.Windows.Forms.PictureBox()
        Me.armor4 = New System.Windows.Forms.PictureBox()
        Me.senjata4 = New System.Windows.Forms.PictureBox()
        Me.fireblast = New System.Windows.Forms.PictureBox()
        Me.armor6 = New System.Windows.Forms.PictureBox()
        Me.senjata5 = New System.Windows.Forms.PictureBox()
        Me.tornado = New System.Windows.Forms.PictureBox()
        Me.armor5 = New System.Windows.Forms.PictureBox()
        Me.senjata6 = New System.Windows.Forms.PictureBox()
        Me.chainbolt = New System.Windows.Forms.PictureBox()
        Me.armor1 = New System.Windows.Forms.PictureBox()
        Me.senjata1 = New System.Windows.Forms.PictureBox()
        Me.sunstrike = New System.Windows.Forms.PictureBox()
        Me.gbrEFEKPUKUL = New System.Windows.Forms.PictureBox()
        Me.Player2 = New System.Windows.Forms.PictureBox()
        Me.Player1 = New System.Windows.Forms.PictureBox()
        Me.lblNILAIHPMON = New System.Windows.Forms.Label()
        Me.btnATTACK = New System.Windows.Forms.Button()
        Me.lblATTACK = New System.Windows.Forms.Label()
        Me.lblDEFF = New System.Windows.Forms.Label()
        Me.lblNILAIATT = New System.Windows.Forms.Label()
        Me.lblNILAIDEFF = New System.Windows.Forms.Label()
        Me.sihir6 = New System.Windows.Forms.PictureBox()
        Me.sihir5 = New System.Windows.Forms.PictureBox()
        Me.sihir4 = New System.Windows.Forms.PictureBox()
        Me.sihir1 = New System.Windows.Forms.PictureBox()
        Me.sihir3 = New System.Windows.Forms.PictureBox()
        Me.sihir2 = New System.Windows.Forms.PictureBox()
        Me.Monsterlevel1 = New System.Windows.Forms.PictureBox()
        Me.nomoney = New System.Windows.Forms.Timer(Me.components)
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tmrAttack = New System.Windows.Forms.Timer(Me.components)
        Me.tmrBACK = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPUKUL = New System.Windows.Forms.Timer(Me.components)
        Me.grpITEMS = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.background = New System.Windows.Forms.GroupBox()
        Me.pbMONSTER = New System.Windows.Forms.ProgressBar()
        Me.pbPLAYER = New System.Windows.Forms.ProgressBar()
        Me.lblBOSS = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnNEXT = New System.Windows.Forms.Button()
        Me.lblHPMONSTER = New System.Windows.Forms.Label()
        Me.grpSTAT = New System.Windows.Forms.GroupBox()
        Me.lblHP = New System.Windows.Forms.Label()
        Me.lblNILAIHP = New System.Windows.Forms.Label()
        Me.lblLEVEL = New System.Windows.Forms.Label()
        Me.lblNILAILEVEL = New System.Windows.Forms.Label()
        Me.tmrBOSS = New System.Windows.Forms.Timer(Me.components)
        CType(Me.senjata2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.frostbite, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.armor2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.senjata3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.armor3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Lightningbolt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.armor4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.senjata4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fireblast, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.armor6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.senjata5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tornado, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.armor5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.senjata6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.chainbolt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.armor1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.senjata1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sunstrike, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.gbrEFEKPUKUL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Player2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Player1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sihir6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sihir5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sihir4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sihir1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sihir3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sihir2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Monsterlevel1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpITEMS.SuspendLayout()
        Me.background.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.grpSTAT.SuspendLayout()
        Me.SuspendLayout()
        '
        'Show
        '
        Me.Show.Interval = 10
        '
        'btnSHOP
        '
        Me.btnSHOP.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSHOP.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSHOP.Location = New System.Drawing.Point(473, 354)
        Me.btnSHOP.Name = "btnSHOP"
        Me.btnSHOP.Size = New System.Drawing.Size(53, 27)
        Me.btnSHOP.TabIndex = 1
        Me.btnSHOP.Text = "SHOP"
        Me.ToolTip1.SetToolTip(Me.btnSHOP, "Buy Item and Magic" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "For your Hero")
        Me.btnSHOP.UseVisualStyleBackColor = True
        '
        'Hide
        '
        Me.Hide.Interval = 10
        '
        'lblMONEY
        '
        Me.lblMONEY.AutoSize = True
        Me.lblMONEY.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMONEY.Location = New System.Drawing.Point(63, 9)
        Me.lblMONEY.Name = "lblMONEY"
        Me.lblMONEY.Size = New System.Drawing.Size(63, 22)
        Me.lblMONEY.TabIndex = 7
        Me.lblMONEY.Text = "Money"
        Me.lblMONEY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblMONEY, "Your Current Gold")
        '
        'lblINFORMASI
        '
        Me.lblINFORMASI.AutoSize = True
        Me.lblINFORMASI.BackColor = System.Drawing.Color.Transparent
        Me.lblINFORMASI.Font = New System.Drawing.Font("Kristen ITC", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblINFORMASI.ForeColor = System.Drawing.Color.Red
        Me.lblINFORMASI.Location = New System.Drawing.Point(188, 31)
        Me.lblINFORMASI.Name = "lblINFORMASI"
        Me.lblINFORMASI.Size = New System.Drawing.Size(110, 29)
        Me.lblINFORMASI.TabIndex = 8
        Me.lblINFORMASI.Text = "nomoney"
        '
        'ToolTip1
        '
        Me.ToolTip1.BackColor = System.Drawing.SystemColors.Control
        Me.ToolTip1.ForeColor = System.Drawing.Color.Black
        Me.ToolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ToolTip1.ToolTipTitle = "Object Information"
        '
        'senjata2
        '
        Me.senjata2.BackColor = System.Drawing.SystemColors.Control
        Me.senjata2.BackgroundImage = Global.game2.My.Resources.Resources.멋진_사무라이_검_katana_열쇠_고리_keyring_pandent_japanes_애니메이션_만화_3_9_
        Me.senjata2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.senjata2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.senjata2.Location = New System.Drawing.Point(11, 37)
        Me.senjata2.Name = "senjata2"
        Me.senjata2.Size = New System.Drawing.Size(41, 37)
        Me.senjata2.TabIndex = 10
        Me.senjata2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.senjata2, "Kellen Dagger" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 500 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 5")
        '
        'frostbite
        '
        Me.frostbite.BackColor = System.Drawing.Color.Crimson
        Me.frostbite.BackgroundImage = Global.game2.My.Resources.Resources.ch
        Me.frostbite.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.frostbite.Cursor = System.Windows.Forms.Cursors.Hand
        Me.frostbite.Location = New System.Drawing.Point(11, 285)
        Me.frostbite.Name = "frostbite"
        Me.frostbite.Size = New System.Drawing.Size(41, 37)
        Me.frostbite.TabIndex = 26
        Me.frostbite.TabStop = False
        Me.ToolTip1.SetToolTip(Me.frostbite, "Frost Bite" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 5200 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Magic Damage + 53" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Element : Ice" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'armor2
        '
        Me.armor2.BackColor = System.Drawing.Color.Chocolate
        Me.armor2.BackgroundImage = Global.game2.My.Resources.Resources.Padded_Armor
        Me.armor2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.armor2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.armor2.Location = New System.Drawing.Point(57, 141)
        Me.armor2.Name = "armor2"
        Me.armor2.Size = New System.Drawing.Size(41, 37)
        Me.armor2.TabIndex = 16
        Me.armor2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.armor2, "Chainmail" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 700 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Armor + 5" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 2")
        '
        'senjata3
        '
        Me.senjata3.BackColor = System.Drawing.SystemColors.Control
        Me.senjata3.BackgroundImage = Global.game2.My.Resources.Resources.eac5bd725ea8ac89a034fa6539d7e758
        Me.senjata3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.senjata3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.senjata3.Location = New System.Drawing.Point(58, 37)
        Me.senjata3.Name = "senjata3"
        Me.senjata3.Size = New System.Drawing.Size(41, 37)
        Me.senjata3.TabIndex = 9
        Me.senjata3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.senjata3, "Horn Axes" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 800 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 9")
        '
        'armor3
        '
        Me.armor3.BackColor = System.Drawing.Color.Chocolate
        Me.armor3.BackgroundImage = Global.game2.My.Resources.Resources.kjbjb
        Me.armor3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.armor3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.armor3.Location = New System.Drawing.Point(104, 141)
        Me.armor3.Name = "armor3"
        Me.armor3.Size = New System.Drawing.Size(41, 37)
        Me.armor3.TabIndex = 15
        Me.armor3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.armor3, "Metal Armor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 1300 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Armor + 7" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Arrack + 5")
        '
        'Lightningbolt
        '
        Me.Lightningbolt.BackColor = System.Drawing.Color.Crimson
        Me.Lightningbolt.BackgroundImage = Global.game2.My.Resources.Resources.emp
        Me.Lightningbolt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Lightningbolt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Lightningbolt.Location = New System.Drawing.Point(57, 285)
        Me.Lightningbolt.Name = "Lightningbolt"
        Me.Lightningbolt.Size = New System.Drawing.Size(41, 37)
        Me.Lightningbolt.TabIndex = 25
        Me.Lightningbolt.TabStop = False
        Me.ToolTip1.SetToolTip(Me.Lightningbolt, "Lightning Bolt" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 5500 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Magic Damage + 58" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Element : Wind" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'armor4
        '
        Me.armor4.BackColor = System.Drawing.Color.Chocolate
        Me.armor4.BackgroundImage = Global.game2.My.Resources.Resources._5460c8f00ab38c43c030ebd59c3f546f
        Me.armor4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.armor4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.armor4.Location = New System.Drawing.Point(11, 184)
        Me.armor4.Name = "armor4"
        Me.armor4.Size = New System.Drawing.Size(41, 37)
        Me.armor4.TabIndex = 17
        Me.armor4.TabStop = False
        Me.ToolTip1.SetToolTip(Me.armor4, "Samurai Armor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 1700 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Armor + 6" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 9")
        '
        'senjata4
        '
        Me.senjata4.BackColor = System.Drawing.SystemColors.Control
        Me.senjata4.BackgroundImage = Global.game2.My.Resources.Resources.sword_of_omens_by_ricardocoutinho_d496mgd
        Me.senjata4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.senjata4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.senjata4.Location = New System.Drawing.Point(58, 80)
        Me.senjata4.Name = "senjata4"
        Me.senjata4.Size = New System.Drawing.Size(41, 37)
        Me.senjata4.TabIndex = 14
        Me.senjata4.TabStop = False
        Me.ToolTip1.SetToolTip(Me.senjata4, "Claymore" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 1800 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 26" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'fireblast
        '
        Me.fireblast.BackColor = System.Drawing.Color.Crimson
        Me.fireblast.BackgroundImage = Global.game2.My.Resources.Resources.Dota_IMBA_LAGOONA_BLAZE_IT_icon
        Me.fireblast.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.fireblast.Cursor = System.Windows.Forms.Cursors.Hand
        Me.fireblast.Location = New System.Drawing.Point(104, 285)
        Me.fireblast.Name = "fireblast"
        Me.fireblast.Size = New System.Drawing.Size(41, 37)
        Me.fireblast.TabIndex = 24
        Me.fireblast.TabStop = False
        Me.ToolTip1.SetToolTip(Me.fireblast, "Fire Blast" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 8000 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Magic Damage + 100" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Element : Fire + Thunder" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'armor6
        '
        Me.armor6.BackColor = System.Drawing.Color.Chocolate
        Me.armor6.BackgroundImage = Global.game2.My.Resources.Resources.kjhjk
        Me.armor6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.armor6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.armor6.Location = New System.Drawing.Point(104, 184)
        Me.armor6.Name = "armor6"
        Me.armor6.Size = New System.Drawing.Size(41, 37)
        Me.armor6.TabIndex = 18
        Me.armor6.TabStop = False
        Me.ToolTip1.SetToolTip(Me.armor6, "The Luxury Armor : Emperor of Ishgar Golden Armor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 100000 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Armor +" & _
        " 5000" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 5000" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'senjata5
        '
        Me.senjata5.BackColor = System.Drawing.SystemColors.Control
        Me.senjata5.BackgroundImage = Global.game2.My.Resources.Resources.images
        Me.senjata5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.senjata5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.senjata5.Location = New System.Drawing.Point(104, 37)
        Me.senjata5.Name = "senjata5"
        Me.senjata5.Size = New System.Drawing.Size(41, 37)
        Me.senjata5.TabIndex = 13
        Me.senjata5.TabStop = False
        Me.ToolTip1.SetToolTip(Me.senjata5, "Katana" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 1200 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 18" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'tornado
        '
        Me.tornado.BackColor = System.Drawing.Color.Crimson
        Me.tornado.BackgroundImage = Global.game2.My.Resources.Resources._120px_Dark_Artistry_Tornado_icon
        Me.tornado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.tornado.Cursor = System.Windows.Forms.Cursors.Hand
        Me.tornado.Location = New System.Drawing.Point(11, 242)
        Me.tornado.Name = "tornado"
        Me.tornado.Size = New System.Drawing.Size(41, 37)
        Me.tornado.TabIndex = 23
        Me.tornado.TabStop = False
        Me.ToolTip1.SetToolTip(Me.tornado, "Tornado" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 4000 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Magic Damage + 40" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Element : Wind")
        '
        'armor5
        '
        Me.armor5.BackColor = System.Drawing.Color.Chocolate
        Me.armor5.BackgroundImage = Global.game2.My.Resources.Resources.jghjh
        Me.armor5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.armor5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.armor5.Location = New System.Drawing.Point(57, 184)
        Me.armor5.Name = "armor5"
        Me.armor5.Size = New System.Drawing.Size(41, 37)
        Me.armor5.TabIndex = 19
        Me.armor5.TabStop = False
        Me.ToolTip1.SetToolTip(Me.armor5, "Ishgar Knight Armor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 2200 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Armor + 10" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 10" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'senjata6
        '
        Me.senjata6.BackColor = System.Drawing.Color.Black
        Me.senjata6.BackgroundImage = Global.game2.My.Resources.Resources.pedang_1
        Me.senjata6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.senjata6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.senjata6.Location = New System.Drawing.Point(104, 80)
        Me.senjata6.Name = "senjata6"
        Me.senjata6.Size = New System.Drawing.Size(41, 37)
        Me.senjata6.TabIndex = 12
        Me.senjata6.TabStop = False
        Me.ToolTip1.SetToolTip(Me.senjata6, "The Legendary Sword : Excalibur" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 100000 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 10000")
        '
        'chainbolt
        '
        Me.chainbolt.BackColor = System.Drawing.Color.Crimson
        Me.chainbolt.BackgroundImage = Global.game2.My.Resources.Resources._2603988_razor_eye_of_the_storm
        Me.chainbolt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.chainbolt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chainbolt.Location = New System.Drawing.Point(57, 242)
        Me.chainbolt.Name = "chainbolt"
        Me.chainbolt.Size = New System.Drawing.Size(41, 37)
        Me.chainbolt.TabIndex = 22
        Me.chainbolt.TabStop = False
        Me.ToolTip1.SetToolTip(Me.chainbolt, "Chain Bolt" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 4600 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Magic Damage + 47" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Element : Thunder" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'armor1
        '
        Me.armor1.BackColor = System.Drawing.Color.Chocolate
        Me.armor1.BackgroundImage = Global.game2.My.Resources.Resources.bvnv
        Me.armor1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.armor1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.armor1.Location = New System.Drawing.Point(10, 141)
        Me.armor1.Name = "armor1"
        Me.armor1.Size = New System.Drawing.Size(41, 37)
        Me.armor1.TabIndex = 20
        Me.armor1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.armor1, "Leather Armor" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 400 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Armor + 4")
        '
        'senjata1
        '
        Me.senjata1.BackColor = System.Drawing.SystemColors.Control
        Me.senjata1.BackgroundImage = Global.game2.My.Resources.Resources.Excalibur_fantasy_weapons_4278339_800_600
        Me.senjata1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.senjata1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.senjata1.Location = New System.Drawing.Point(11, 80)
        Me.senjata1.Name = "senjata1"
        Me.senjata1.Size = New System.Drawing.Size(41, 37)
        Me.senjata1.TabIndex = 11
        Me.senjata1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.senjata1, "Broad Sword" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 1400 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Attack + 20")
        '
        'sunstrike
        '
        Me.sunstrike.BackColor = System.Drawing.Color.Crimson
        Me.sunstrike.BackgroundImage = Global.game2.My.Resources.Resources._286585_small
        Me.sunstrike.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sunstrike.Cursor = System.Windows.Forms.Cursors.Hand
        Me.sunstrike.Location = New System.Drawing.Point(104, 242)
        Me.sunstrike.Name = "sunstrike"
        Me.sunstrike.Size = New System.Drawing.Size(41, 37)
        Me.sunstrike.TabIndex = 21
        Me.sunstrike.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sunstrike, "Sun Strike" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Price : 5000 Gold" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Magic Damage + 50" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Element : Fire" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'gbrEFEKPUKUL
        '
        Me.gbrEFEKPUKUL.BackColor = System.Drawing.Color.Transparent
        Me.gbrEFEKPUKUL.BackgroundImage = Global.game2.My.Resources.Resources.merah_bintang_clip_art_vektor_gratis_download_241346
        Me.gbrEFEKPUKUL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.gbrEFEKPUKUL.Location = New System.Drawing.Point(321, 117)
        Me.gbrEFEKPUKUL.Name = "gbrEFEKPUKUL"
        Me.gbrEFEKPUKUL.Size = New System.Drawing.Size(54, 57)
        Me.gbrEFEKPUKUL.TabIndex = 48
        Me.gbrEFEKPUKUL.TabStop = False
        Me.ToolTip1.SetToolTip(Me.gbrEFEKPUKUL, "For Magic Spell ")
        '
        'Player2
        '
        Me.Player2.BackColor = System.Drawing.Color.Transparent
        Me.Player2.BackgroundImage = Global.game2.My.Resources.Resources.Players
        Me.Player2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Player2.Location = New System.Drawing.Point(358, 206)
        Me.Player2.Name = "Player2"
        Me.Player2.Size = New System.Drawing.Size(64, 95)
        Me.Player2.TabIndex = 47
        Me.Player2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.Player2, "Your Avatar")
        '
        'Player1
        '
        Me.Player1.BackColor = System.Drawing.Color.Transparent
        Me.Player1.BackgroundImage = Global.game2.My.Resources.Resources.Players
        Me.Player1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Player1.Location = New System.Drawing.Point(444, 191)
        Me.Player1.Name = "Player1"
        Me.Player1.Size = New System.Drawing.Size(111, 154)
        Me.Player1.TabIndex = 46
        Me.Player1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.Player1, "Your Avatar")
        '
        'lblNILAIHPMON
        '
        Me.lblNILAIHPMON.AutoSize = True
        Me.lblNILAIHPMON.BackColor = System.Drawing.Color.Transparent
        Me.lblNILAIHPMON.Font = New System.Drawing.Font("Hobo Std", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNILAIHPMON.Location = New System.Drawing.Point(265, 105)
        Me.lblNILAIHPMON.Name = "lblNILAIHPMON"
        Me.lblNILAIHPMON.Size = New System.Drawing.Size(30, 23)
        Me.lblNILAIHPMON.TabIndex = 42
        Me.lblNILAIHPMON.Text = "25"
        Me.ToolTip1.SetToolTip(Me.lblNILAIHPMON, "Enemies Current HP")
        '
        'btnATTACK
        '
        Me.btnATTACK.BackColor = System.Drawing.Color.Red
        Me.btnATTACK.BackgroundImage = Global.game2.My.Resources.Resources.dcn1adwq0ws
        Me.btnATTACK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnATTACK.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnATTACK.Font = New System.Drawing.Font("Modern No. 20", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnATTACK.Location = New System.Drawing.Point(13, 292)
        Me.btnATTACK.Name = "btnATTACK"
        Me.btnATTACK.Size = New System.Drawing.Size(41, 39)
        Me.btnATTACK.TabIndex = 40
        Me.ToolTip1.SetToolTip(Me.btnATTACK, "Give Enemy Physical Damage")
        Me.btnATTACK.UseVisualStyleBackColor = False
        '
        'lblATTACK
        '
        Me.lblATTACK.AutoSize = True
        Me.lblATTACK.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblATTACK.Location = New System.Drawing.Point(4, 74)
        Me.lblATTACK.Name = "lblATTACK"
        Me.lblATTACK.Size = New System.Drawing.Size(63, 22)
        Me.lblATTACK.TabIndex = 2
        Me.lblATTACK.Text = "Attack"
        Me.ToolTip1.SetToolTip(Me.lblATTACK, "Physical Damage to Enemy")
        '
        'lblDEFF
        '
        Me.lblDEFF.AutoSize = True
        Me.lblDEFF.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDEFF.Location = New System.Drawing.Point(4, 100)
        Me.lblDEFF.Name = "lblDEFF"
        Me.lblDEFF.Size = New System.Drawing.Size(78, 22)
        Me.lblDEFF.TabIndex = 3
        Me.lblDEFF.Text = "Deffence"
        Me.ToolTip1.SetToolTip(Me.lblDEFF, "Physical Deffence From Enemy")
        '
        'lblNILAIATT
        '
        Me.lblNILAIATT.AutoSize = True
        Me.lblNILAIATT.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNILAIATT.Location = New System.Drawing.Point(88, 76)
        Me.lblNILAIATT.Name = "lblNILAIATT"
        Me.lblNILAIATT.Size = New System.Drawing.Size(19, 22)
        Me.lblNILAIATT.TabIndex = 4
        Me.lblNILAIATT.Text = "0"
        Me.lblNILAIATT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblNILAIATT, "Our Current Damage")
        '
        'lblNILAIDEFF
        '
        Me.lblNILAIDEFF.AutoSize = True
        Me.lblNILAIDEFF.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNILAIDEFF.Location = New System.Drawing.Point(88, 101)
        Me.lblNILAIDEFF.Name = "lblNILAIDEFF"
        Me.lblNILAIDEFF.Size = New System.Drawing.Size(19, 22)
        Me.lblNILAIDEFF.TabIndex = 5
        Me.lblNILAIDEFF.Text = "0"
        Me.lblNILAIDEFF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblNILAIDEFF, "Our Current Deffence")
        '
        'sihir6
        '
        Me.sihir6.BackColor = System.Drawing.SystemColors.Control
        Me.sihir6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sihir6.Location = New System.Drawing.Point(201, 337)
        Me.sihir6.Name = "sihir6"
        Me.sihir6.Size = New System.Drawing.Size(41, 37)
        Me.sihir6.TabIndex = 27
        Me.sihir6.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sihir6, "For Magic Spell ")
        '
        'sihir5
        '
        Me.sihir5.BackColor = System.Drawing.SystemColors.Control
        Me.sihir5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sihir5.Location = New System.Drawing.Point(107, 337)
        Me.sihir5.Name = "sihir5"
        Me.sihir5.Size = New System.Drawing.Size(41, 37)
        Me.sihir5.TabIndex = 29
        Me.sihir5.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sihir5, "For Magic Spell ")
        '
        'sihir4
        '
        Me.sihir4.BackColor = System.Drawing.SystemColors.Control
        Me.sihir4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sihir4.Location = New System.Drawing.Point(154, 337)
        Me.sihir4.Name = "sihir4"
        Me.sihir4.Size = New System.Drawing.Size(41, 37)
        Me.sihir4.TabIndex = 31
        Me.sihir4.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sihir4, "For Magic Spell ")
        '
        'sihir1
        '
        Me.sihir1.BackColor = System.Drawing.SystemColors.Control
        Me.sihir1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sihir1.Location = New System.Drawing.Point(248, 337)
        Me.sihir1.Name = "sihir1"
        Me.sihir1.Size = New System.Drawing.Size(41, 37)
        Me.sihir1.TabIndex = 28
        Me.sihir1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sihir1, "For Magic Spell ")
        '
        'sihir3
        '
        Me.sihir3.BackColor = System.Drawing.SystemColors.Control
        Me.sihir3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sihir3.Location = New System.Drawing.Point(60, 337)
        Me.sihir3.Name = "sihir3"
        Me.sihir3.Size = New System.Drawing.Size(41, 37)
        Me.sihir3.TabIndex = 32
        Me.sihir3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sihir3, "For Magic Spell ")
        '
        'sihir2
        '
        Me.sihir2.BackColor = System.Drawing.SystemColors.Control
        Me.sihir2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sihir2.Location = New System.Drawing.Point(13, 337)
        Me.sihir2.Name = "sihir2"
        Me.sihir2.Size = New System.Drawing.Size(41, 37)
        Me.sihir2.TabIndex = 30
        Me.sihir2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.sihir2, "For Magic Spell ")
        '
        'Monsterlevel1
        '
        Me.Monsterlevel1.BackColor = System.Drawing.Color.Transparent
        Me.Monsterlevel1.BackgroundImage = Global.game2.My.Resources.Resources.esports_dota_2_quai_rung_Satyr_Tormenter
        Me.Monsterlevel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Monsterlevel1.Location = New System.Drawing.Point(204, 145)
        Me.Monsterlevel1.Name = "Monsterlevel1"
        Me.Monsterlevel1.Size = New System.Drawing.Size(136, 128)
        Me.Monsterlevel1.TabIndex = 44
        Me.Monsterlevel1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.Monsterlevel1, "Monster Lawan")
        '
        'nomoney
        '
        Me.nomoney.Interval = 200
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(190, 393)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(209, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Created By: Fahmi Roihanul Firdaus"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Gold
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(110, 15)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 13)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "GOLD"
        '
        'tmrAttack
        '
        Me.tmrAttack.Interval = 50
        '
        'tmrBACK
        '
        '
        'tmrPUKUL
        '
        Me.tmrPUKUL.Interval = 10
        '
        'grpITEMS
        '
        Me.grpITEMS.BackColor = System.Drawing.Color.Maroon
        Me.grpITEMS.BackgroundImage = Global.game2.My.Resources.Resources.wood_grain_texture_textured_wallpaper_dark_collection_images_textures_wallpapers
        Me.grpITEMS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.grpITEMS.Controls.Add(Me.senjata2)
        Me.grpITEMS.Controls.Add(Me.frostbite)
        Me.grpITEMS.Controls.Add(Me.armor2)
        Me.grpITEMS.Controls.Add(Me.senjata3)
        Me.grpITEMS.Controls.Add(Me.armor3)
        Me.grpITEMS.Controls.Add(Me.Lightningbolt)
        Me.grpITEMS.Controls.Add(Me.armor4)
        Me.grpITEMS.Controls.Add(Me.Label1)
        Me.grpITEMS.Controls.Add(Me.senjata4)
        Me.grpITEMS.Controls.Add(Me.fireblast)
        Me.grpITEMS.Controls.Add(Me.armor6)
        Me.grpITEMS.Controls.Add(Me.Label2)
        Me.grpITEMS.Controls.Add(Me.senjata5)
        Me.grpITEMS.Controls.Add(Me.tornado)
        Me.grpITEMS.Controls.Add(Me.armor5)
        Me.grpITEMS.Controls.Add(Me.Label3)
        Me.grpITEMS.Controls.Add(Me.senjata6)
        Me.grpITEMS.Controls.Add(Me.chainbolt)
        Me.grpITEMS.Controls.Add(Me.armor1)
        Me.grpITEMS.Controls.Add(Me.senjata1)
        Me.grpITEMS.Controls.Add(Me.sunstrike)
        Me.grpITEMS.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpITEMS.ForeColor = System.Drawing.SystemColors.Control
        Me.grpITEMS.Location = New System.Drawing.Point(650, 12)
        Me.grpITEMS.Name = "grpITEMS"
        Me.grpITEMS.Size = New System.Drawing.Size(157, 333)
        Me.grpITEMS.TabIndex = 44
        Me.grpITEMS.TabStop = False
        Me.grpITEMS.Text = "Item Shop"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Weapon"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(9, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Armor"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 225)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Magic"
        '
        'background
        '
        Me.background.BackColor = System.Drawing.Color.Transparent
        Me.background.BackgroundImage = Global.game2.My.Resources.Resources.Arena_Battle_Background
        Me.background.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.background.Controls.Add(Me.pbMONSTER)
        Me.background.Controls.Add(Me.pbPLAYER)
        Me.background.Controls.Add(Me.lblBOSS)
        Me.background.Controls.Add(Me.GroupBox1)
        Me.background.Controls.Add(Me.gbrEFEKPUKUL)
        Me.background.Controls.Add(Me.lblINFORMASI)
        Me.background.Controls.Add(Me.btnNEXT)
        Me.background.Controls.Add(Me.Player2)
        Me.background.Controls.Add(Me.Player1)
        Me.background.Controls.Add(Me.lblNILAIHPMON)
        Me.background.Controls.Add(Me.lblHPMONSTER)
        Me.background.Controls.Add(Me.btnATTACK)
        Me.background.Controls.Add(Me.Monsterlevel1)
        Me.background.Controls.Add(Me.grpSTAT)
        Me.background.Controls.Add(Me.sihir6)
        Me.background.Controls.Add(Me.sihir5)
        Me.background.Controls.Add(Me.sihir4)
        Me.background.Controls.Add(Me.sihir1)
        Me.background.Controls.Add(Me.sihir3)
        Me.background.Controls.Add(Me.sihir2)
        Me.background.Location = New System.Drawing.Point(0, 0)
        Me.background.Name = "background"
        Me.background.Size = New System.Drawing.Size(629, 390)
        Me.background.TabIndex = 0
        Me.background.TabStop = False
        Me.background.Text = "Arena"
        '
        'pbMONSTER
        '
        Me.pbMONSTER.Location = New System.Drawing.Point(225, 133)
        Me.pbMONSTER.Name = "pbMONSTER"
        Me.pbMONSTER.Size = New System.Drawing.Size(79, 10)
        Me.pbMONSTER.TabIndex = 50
        '
        'pbPLAYER
        '
        Me.pbPLAYER.Location = New System.Drawing.Point(445, 180)
        Me.pbPLAYER.Name = "pbPLAYER"
        Me.pbPLAYER.Size = New System.Drawing.Size(92, 10)
        Me.pbPLAYER.TabIndex = 45
        '
        'lblBOSS
        '
        Me.lblBOSS.AutoSize = True
        Me.lblBOSS.BackColor = System.Drawing.Color.Transparent
        Me.lblBOSS.Font = New System.Drawing.Font("Algerian", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBOSS.ForeColor = System.Drawing.Color.Red
        Me.lblBOSS.Location = New System.Drawing.Point(233, 79)
        Me.lblBOSS.Name = "lblBOSS"
        Me.lblBOSS.Size = New System.Drawing.Size(65, 24)
        Me.lblBOSS.TabIndex = 49
        Me.lblBOSS.Text = "BOSS"
        Me.lblBOSS.Visible = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Gold
        Me.GroupBox1.Controls.Add(Me.lblMONEY)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(469, 350)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(156, 34)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        '
        'btnNEXT
        '
        Me.btnNEXT.BackColor = System.Drawing.Color.Transparent
        Me.btnNEXT.BackgroundImage = Global.game2.My.Resources.Resources.next_icon_2970
        Me.btnNEXT.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnNEXT.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnNEXT.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNEXT.Location = New System.Drawing.Point(539, 17)
        Me.btnNEXT.Name = "btnNEXT"
        Me.btnNEXT.Size = New System.Drawing.Size(77, 74)
        Me.btnNEXT.TabIndex = 43
        Me.btnNEXT.UseVisualStyleBackColor = False
        '
        'lblHPMONSTER
        '
        Me.lblHPMONSTER.AutoSize = True
        Me.lblHPMONSTER.BackColor = System.Drawing.Color.Transparent
        Me.lblHPMONSTER.Font = New System.Drawing.Font("Hobo Std", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHPMONSTER.Location = New System.Drawing.Point(235, 105)
        Me.lblHPMONSTER.Name = "lblHPMONSTER"
        Me.lblHPMONSTER.Size = New System.Drawing.Size(32, 23)
        Me.lblHPMONSTER.TabIndex = 41
        Me.lblHPMONSTER.Text = "HP"
        '
        'grpSTAT
        '
        Me.grpSTAT.BackColor = System.Drawing.Color.Transparent
        Me.grpSTAT.Controls.Add(Me.lblATTACK)
        Me.grpSTAT.Controls.Add(Me.lblDEFF)
        Me.grpSTAT.Controls.Add(Me.lblNILAIATT)
        Me.grpSTAT.Controls.Add(Me.lblNILAIDEFF)
        Me.grpSTAT.Controls.Add(Me.lblHP)
        Me.grpSTAT.Controls.Add(Me.lblNILAIHP)
        Me.grpSTAT.Controls.Add(Me.lblLEVEL)
        Me.grpSTAT.Controls.Add(Me.lblNILAILEVEL)
        Me.grpSTAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSTAT.Location = New System.Drawing.Point(12, 19)
        Me.grpSTAT.Name = "grpSTAT"
        Me.grpSTAT.Size = New System.Drawing.Size(124, 134)
        Me.grpSTAT.TabIndex = 0
        Me.grpSTAT.TabStop = False
        Me.grpSTAT.Text = "Player Status"
        '
        'lblHP
        '
        Me.lblHP.AutoSize = True
        Me.lblHP.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHP.Location = New System.Drawing.Point(6, 42)
        Me.lblHP.Name = "lblHP"
        Me.lblHP.Size = New System.Drawing.Size(38, 24)
        Me.lblHP.TabIndex = 36
        Me.lblHP.Text = "HP"
        '
        'lblNILAIHP
        '
        Me.lblNILAIHP.AutoSize = True
        Me.lblNILAIHP.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNILAIHP.Location = New System.Drawing.Point(80, 42)
        Me.lblNILAIHP.Name = "lblNILAIHP"
        Me.lblNILAIHP.Size = New System.Drawing.Size(21, 24)
        Me.lblNILAIHP.TabIndex = 37
        Me.lblNILAIHP.Text = "0"
        '
        'lblLEVEL
        '
        Me.lblLEVEL.AutoSize = True
        Me.lblLEVEL.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLEVEL.Location = New System.Drawing.Point(6, 16)
        Me.lblLEVEL.Name = "lblLEVEL"
        Me.lblLEVEL.Size = New System.Drawing.Size(60, 24)
        Me.lblLEVEL.TabIndex = 38
        Me.lblLEVEL.Text = "Level"
        '
        'lblNILAILEVEL
        '
        Me.lblNILAILEVEL.AutoSize = True
        Me.lblNILAILEVEL.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNILAILEVEL.Location = New System.Drawing.Point(87, 16)
        Me.lblNILAILEVEL.Name = "lblNILAILEVEL"
        Me.lblNILAILEVEL.Size = New System.Drawing.Size(21, 24)
        Me.lblNILAILEVEL.TabIndex = 39
        Me.lblNILAILEVEL.Text = "1"
        '
        'tmrBOSS
        '
        Me.tmrBOSS.Interval = 250
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(629, 386)
        Me.Controls.Add(Me.grpITEMS)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnSHOP)
        Me.Controls.Add(Me.background)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.senjata2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.frostbite, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.armor2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.senjata3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.armor3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Lightningbolt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.armor4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.senjata4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fireblast, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.armor6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.senjata5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tornado, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.armor5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.senjata6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.chainbolt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.armor1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.senjata1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sunstrike, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.gbrEFEKPUKUL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Player2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Player1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sihir6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sihir5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sihir4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sihir1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sihir3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sihir2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Monsterlevel1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpITEMS.ResumeLayout(False)
        Me.grpITEMS.PerformLayout()
        Me.background.ResumeLayout(False)
        Me.background.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grpSTAT.ResumeLayout(False)
        Me.grpSTAT.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents background As GroupBox
    Friend WithEvents Show As Timer
    Friend WithEvents btnSHOP As Button
    Friend WithEvents Hide As Timer
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblATTACK As Label
    Friend WithEvents lblDEFF As Label
    Friend WithEvents lblNILAIATT As Label
    Friend WithEvents lblNILAIDEFF As Label
    Friend WithEvents lblMONEY As Label
    Friend WithEvents lblINFORMASI As Label
    Friend WithEvents frostbite As PictureBox
    Friend WithEvents Lightningbolt As PictureBox
    Friend WithEvents fireblast As PictureBox
    Friend WithEvents tornado As PictureBox
    Friend WithEvents chainbolt As PictureBox
    Friend WithEvents sunstrike As PictureBox
    Friend WithEvents armor1 As PictureBox
    Friend WithEvents armor5 As PictureBox
    Friend WithEvents armor6 As PictureBox
    Friend WithEvents armor4 As PictureBox
    Friend WithEvents armor2 As PictureBox
    Friend WithEvents armor3 As PictureBox
    Friend WithEvents senjata4 As PictureBox
    Friend WithEvents senjata5 As PictureBox
    Friend WithEvents senjata6 As PictureBox
    Friend WithEvents senjata1 As PictureBox
    Friend WithEvents senjata2 As PictureBox
    Friend WithEvents senjata3 As PictureBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents sihir3 As PictureBox
    Friend WithEvents sihir4 As PictureBox
    Friend WithEvents sihir2 As PictureBox
    Friend WithEvents sihir5 As PictureBox
    Friend WithEvents sihir1 As PictureBox
    Friend WithEvents sihir6 As PictureBox
    Friend WithEvents nomoney As Timer
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblHP As Label
    Friend WithEvents lblNILAIHP As Label
    Friend WithEvents lblLEVEL As Label
    Friend WithEvents lblNILAILEVEL As Label
    Friend WithEvents btnATTACK As Button
    Friend WithEvents tmrBACK As Timer
    Friend WithEvents lblHPMONSTER As Label
    Friend WithEvents lblNILAIHPMON As Label
    Friend WithEvents tmrPUKUL As Timer
    Friend WithEvents tmrAttack As Timer
    Friend WithEvents Player2 As PictureBox
    Friend WithEvents Player1 As PictureBox
    Friend WithEvents Monsterlevel1 As PictureBox
    Friend WithEvents grpSTAT As GroupBox
    Friend WithEvents grpITEMS As GroupBox
    Friend WithEvents gbrEFEKPUKUL As PictureBox
    Friend WithEvents btnNEXT As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblBOSS As Label
    Friend WithEvents tmrBOSS As Timer
    Friend WithEvents pbMONSTER As ProgressBar
    Friend WithEvents pbPLAYER As ProgressBar
End Class
